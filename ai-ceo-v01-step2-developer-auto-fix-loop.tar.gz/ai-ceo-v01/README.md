# AI CEO v0.1

A starter control center for an autonomous AI CEO / agent factory.

## Run
npm install
npm run dev

## Roadmap
1. CEO planning engine
2. Supabase persistence
3. Tool registry + permissions
4. Background task runner
5. Specialist agents
6. Agent factory
7. Evaluation/self-improvement
8. Production deployment


## Step 7 — Developer Auto-Fix Loop

The system now has a guarded repair-job path:

QA failure → repair task → `developer_repair_jobs` → external Developer Worker → tests/build → callback → original task retest.

The worker only edits files inside `DEVELOPER_WORKSPACE_ROOT`, protects `.git` and secret files, allows only `npm test`, `npm run build`, `npm run lint`, and `node --test`, and rolls back patches when checks fail.

The Supabase callback resets the original task to `pending` only after a successful repair, so the normal autonomous orchestrator can execute it again and create a fresh QA result.

The remaining connection is the Developer Worker itself: it must run in a trusted workspace/CI environment and receive generated patches. The current Supabase project does not yet have a connected production repository/Vercel workspace, so this layer is implemented but not falsely marked as fully autonomous production execution.
