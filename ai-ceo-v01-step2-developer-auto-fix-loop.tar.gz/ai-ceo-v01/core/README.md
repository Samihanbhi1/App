# AI CEO v0.1 core

Planned modules:
- orchestrator: converts owner goals into executable plans
- planner: creates tasks/dependencies
- executor: invokes approved tools
- evaluator: verifies outcomes
- memory: persists decisions, results and learnings
- permissions: gates consequential actions

The UI is intentionally usable before external services are connected.
