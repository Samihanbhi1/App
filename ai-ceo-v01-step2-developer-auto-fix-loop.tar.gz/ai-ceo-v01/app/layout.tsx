import React from 'react';
import './styles.css';
export const metadata={title:'AI CEO v0.1',description:'Autonomous AI CEO control center'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
