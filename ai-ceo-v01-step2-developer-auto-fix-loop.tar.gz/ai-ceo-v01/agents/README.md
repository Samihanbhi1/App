# Agents

Initial roster:
- CEO: orchestration and owner interface
- Researcher: research and intelligence
- Developer: implementation
- QA: testing and verification

Next phase adds persistent agent definitions, tools, permissions and run history.
