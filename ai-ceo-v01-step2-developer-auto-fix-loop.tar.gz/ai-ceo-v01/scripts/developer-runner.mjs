#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';

const ROOT = path.resolve(process.env.DEVELOPER_WORKSPACE_ROOT || process.cwd());
const DANGEROUS = /(^|\s)(rm|sudo|chmod|chown|curl|wget|nc|ssh|scp|git\s+push|git\s+reset\s+--hard|npm\s+publish)(\s|$)/i;
const ALLOWED = new Set(['npm test','npm run build','npm run lint','node --test']);

function fail(message){ throw new Error(message); }
function insideRoot(p){ const r=path.resolve(p); return r===ROOT || r.startsWith(ROOT+path.sep); }
function validatePath(p){
  if(!p || typeof p!=='string') fail('path is required');
  if(p.includes('\0')) fail('invalid path');
  const abs=path.resolve(ROOT,p);
  if(!insideRoot(abs)) fail('path escapes workspace');
  const rel=path.relative(ROOT,abs);
  if(rel.split(path.sep).includes('.git')) fail('git directory is protected');
  if(/(^|[\\/])\.env($|\.)/.test(rel) || /(^|[\\/])(secrets?|credentials?)([\\/]|$)/i.test(rel)) fail('secret path is protected');
  return abs;
}
function validateCommand(command){
  if(typeof command!=='string' || !ALLOWED.has(command) || DANGEROUS.test(command)) fail('command is not allowlisted');
  return command;
}
async function run(command){
  return await new Promise((resolve)=>{
    const child=spawn(command,{cwd:ROOT,shell:true,env:{...process.env,CI:'1'},stdio:['ignore','pipe','pipe']});
    let stdout='',stderr=''; child.stdout.on('data',d=>stdout+=d); child.stderr.on('data',d=>stderr+=d);
    child.on('close',code=>resolve({command,code,stdout:stdout.slice(-12000),stderr:stderr.slice(-12000)}));
  });
}

async function main(){
  const file=process.argv[2];
  if(!file) fail('usage: node scripts/developer-runner.mjs <job.json>');
  const job=JSON.parse(await fs.readFile(validatePath(file),'utf8'));
  const changed=[];
  const backups=[];
  for(const patch of (job.patches||[])){
    const target=validatePath(patch.path);
    const before=await fs.readFile(target,'utf8').catch(()=>null);
    if(typeof patch.content!=='string') fail(`patch content missing for ${patch.path}`);
    backups.push({target,before});
    await fs.writeFile(target,patch.content,'utf8');
    changed.push({path:path.relative(ROOT,target),created:before===null});
  }
  const checks=[];
  for(const command of (job.checks||['npm run build'])) checks.push(await run(validateCommand(command)));
  const passed=checks.every(x=>x.code===0);
  if(!passed){
    for(const b of backups){ if(b.before===null) await fs.rm(b.target,{force:true}); else await fs.writeFile(b.target,b.before,'utf8'); }
  }
  const result={status:passed?'passed':'failed',workspace:ROOT,changed_files:changed,checks,repair_id:job.repair_id||null};
  await fs.writeFile(path.join(ROOT,'.ai-ceo','runner-result.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify(result,null,2));
  process.exitCode=passed?0:1;
}
main().catch(async e=>{const result={status:'rejected',error:e.message}; await fs.mkdir(path.join(ROOT,'.ai-ceo'),{recursive:true}); await fs.writeFile(path.join(ROOT,'.ai-ceo','runner-result.json'),JSON.stringify(result,null,2)); console.error(JSON.stringify(result,null,2)); process.exitCode=2;});
