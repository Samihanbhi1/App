#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';

const ROOT = path.resolve(process.env.DEVELOPER_WORKSPACE_ROOT || process.cwd());
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const CALLBACK_URL = process.env.DEVELOPER_REPAIR_CALLBACK_URL;
const CALLBACK_KEY = process.env.DEVELOPER_REPAIR_CALLBACK_KEY;

function fail(m){throw new Error(m)}
if(!SUPABASE_URL || !SUPABASE_KEY || !CALLBACK_URL || !CALLBACK_KEY) fail('Missing SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, DEVELOPER_REPAIR_CALLBACK_URL or DEVELOPER_REPAIR_CALLBACK_KEY');

const headers={'apikey':SUPABASE_KEY,'Authorization':`Bearer ${SUPABASE_KEY}`,'Content-Type':'application/json'};
async function api(pathname, options={}){
  const r=await fetch(`${SUPABASE_URL}/rest/v1/${pathname}`,{...options,headers:{...headers,...(options.headers||{})}});
  const t=await r.text(); if(!r.ok) throw new Error(`Supabase ${r.status}: ${t.slice(0,1000)}`); return t?JSON.parse(t):null;
}
function insideRoot(p){const r=path.resolve(p);return r===ROOT||r.startsWith(ROOT+path.sep)}
function safePath(p){if(typeof p!=='string'||!p||p.includes('\0')) fail('invalid patch path');const a=path.resolve(ROOT,p);if(!insideRoot(a)) fail('path escapes workspace');const rel=path.relative(ROOT,a);if(rel.split(path.sep).includes('.git')) fail('git protected');if(/(^|[\\/])\.env($|\.)/.test(rel)||/(^|[\\/])(secrets?|credentials?)([\\/]|$)/i.test(rel)) fail('secret path protected');return a}
const allowed=new Set(['npm test','npm run build','npm run lint','node --test']);
function safeCommand(c){if(!allowed.has(c)) fail(`command not allowlisted: ${c}`);return c}
async function run(c){return await new Promise(resolve=>{const p=spawn(c,{cwd:ROOT,shell:true,env:{...process.env,CI:'1'},stdio:['ignore','pipe','pipe']});let out='',err='';p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('close',code=>resolve({command:c,code,stdout:out.slice(-12000),stderr:err.slice(-12000)}));})}
async function callback(payload){const r=await fetch(CALLBACK_URL,{method:'POST',headers:{'Content-Type':'application/json','apikey':CALLBACK_KEY},body:JSON.stringify(payload)});const t=await r.text();if(!r.ok)throw new Error(`callback ${r.status}: ${t}`);return t?JSON.parse(t):null}

const jobs=await api('developer_repair_jobs?status=eq.queued&order=created_at.asc&limit=1');
if(!jobs.length){console.log(JSON.stringify({status:'idle'}));process.exit(0)}
const job=jobs[0];
await api(`developer_repair_jobs?id=eq.${job.id}`,{method:'PATCH',body:JSON.stringify({status:'running',attempts:Number(job.attempts||0)+1,started_at:new Date().toISOString()})});
try{
  const patches=Array.isArray(job.job?.patches)?job.job.patches:[];
  if(!patches.length) fail('No patches supplied; AI patch generation is not connected to this worker');
  const changed=[];
  for(const p of patches){const target=safePath(p.path);await fs.mkdir(path.dirname(target),{recursive:true});await fs.writeFile(target,p.content,'utf8');changed.push(p.path)}
  const checks=(Array.isArray(job.job?.checks)&&job.job.checks.length?job.job.checks:['node --test']).map(safeCommand);
  const results=[];for(const c of checks)results.push(await run(c));
  const passed=results.every(x=>x.code===0);
  const result={status:passed?'passed':'failed',changed_files:changed,checks:results,repair_id:job.repair_id};
  await api(`developer_repair_jobs?id=eq.${job.id}`,{method:'PATCH',body:JSON.stringify({status:passed?'passed':'failed',result,completed_at:new Date().toISOString()})});
  await callback({repair_job_id:job.id,repair_id:job.repair_id,status:result.status,result});
  console.log(JSON.stringify(result,null,2));process.exitCode=passed?0:1;
}catch(e){const result={status:'failed',error:e.message,repair_id:job.repair_id};await api(`developer_repair_jobs?id=eq.${job.id}`,{method:'PATCH',body:JSON.stringify({status:'failed',result,completed_at:new Date().toISOString()})}).catch(()=>{});await callback({repair_job_id:job.id,repair_id:job.repair_id,status:'failed',result}).catch(()=>{});console.error(JSON.stringify(result,null,2));process.exitCode=1}
